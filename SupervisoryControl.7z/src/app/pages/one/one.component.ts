import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { TestData } from '../../models/test-data';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Chart } from 'chart.js';
import { Observable, Subject } from 'rxjs';
import { EventService } from '../../providers/event.service';
import { Utility } from '../../core/utility';




@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit, AfterViewInit, OnDestroy {
  displayedColumns: string[] = ['time', 'metric', 'value'];
  alldata: TestData[];
  dataSource: MatTableDataSource<TestData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('canvas') canvas: ElementRef;
  chart: any = [];
  labels: string[];
  values: number[];
  lightcolor: string = "#58B656";//  transparent
  colorchange = new Subject<string>();
  timerid: any;
  flicker: boolean = true;
  datatimer: any;
  currentdat: TestData;
  constructor(private eventsrv: EventService) {
    this.alldata = Array.from({ length: 60 }, (_, k) => this.createTestData(k + 1));
    this.alldata.sort(function (a, b) {
      return a.time < b.time ? 1 : -1;
    });

    this.dataSource = new MatTableDataSource(this.alldata);
    this.labels = this.alldata.map(x => Utility.dateformat("hh:mm:ss", x.time));
    this.values = this.alldata.map(x => x.value);
    this.currentdat = this.alldata[0];

  }



  lightflicker() {
    this.timerid = setInterval(() => {
      this.flicker = !this.flicker;
      setTimeout(() => {
        this.flicker = !this.flicker;
      }, 500);
    }, 2000)
  }
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource.paginator.pageSize = 6;
    this.colorchange.subscribe(x => {
      this.lightcolor = x;
    })
    // this.chardata();
  }



  createTestData(k: number): TestData {
    return {
      time: new Date(new Date().valueOf() - Math.round(Math.random() * 1000 * 60 * 60 * 12)),
      metric: 'A-series',
      value: 40 + (Math.round(Math.random() * 60))
    }
  }


  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }



  ngAfterViewInit() {
    setTimeout(() => {
      this.init();
    }, 100);

    this.lightflicker();
    this.appenddata();
  }

  //追加数据，每秒钟追加一条记录
  appenddata() {

    this.datatimer = setInterval(() => {
      this.currentdat = {
        time: new Date(),
        metric: 'A-series',
        value: 40 + (Math.round(Math.random() * 50))
      }
      this.alldata.splice(this.alldata.length - 1, 1);
      this.alldata.splice(0, 0, this.currentdat);
      this.dataSource.data = this.alldata;

      this.labels.splice(this.labels.length - 1, 1);
      this.labels.splice(0, 0, Utility.dateformat("hh:mm:ss", this.currentdat.time));

      this.values.splice(this.values.length - 1, 1);
      this.values.splice(0, 0, this.currentdat.value);
      this.chart.update();
      if (this.currentdat.value >= 80) {
        this.eventsrv.publish(this.currentdat);
        this.lightcolor = "red";
      } else {
        this.lightcolor = "#58B656";
      }
      // this.dataSource = new MatTableDataSource(this.alldata);
    }, 1000)
  }







//初始化chartjs绑定数据
  init() {
    Chart.defaults.global.defaultFontColor = 'white';
    Chart.defaults.global.defaultFontSize = 9;
    this.chart = new Chart(this.canvas.nativeElement.getContext('2d'), {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: [
          {
            data: this.values,
            borderColor: "#7CB26A",
            borderWidth: 2,
            pointRadius: 0,
            pointHitRadius: 2,
            pointHoverRadius: 2,
            // pointRadius:2,
            fill: false,
            backgroundColor: "#B8E3B7",
           

          }
          // { 
          //   data: temp_min,
          //   borderColor: "#ffcc00",
          //   fill: false
          // },
        ],

      },

      options: {
        responsive: true,
        maintainAspectRatio: true,
       
        layout: {
          padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
          },
          
          
        },
        legend: {
          display: false
        },
        scales: {
          xAxes: [{
            display: true,
            ticks: {
              autoSkip: true,
               
            },
            gridLines: {
              drawOnChartArea: false, // only want the grid lines for one axis to show up
              color:"#ccc",
          }
          }],
          yAxes: [{
            display: true,
            // stacked: true,
            ticks: {
              autoSkip: true,
              autoSkipPadding:50,
              max: 128,
              min: 0,
            
              callback: function (value, index, values) {
                return value + 'V';
              },
            },
            gridLines: {
              drawOnChartArea: false,  
               color:"#ccc",
              drawBorder:true,

          }
          }],
        }//scales
      }
    });
  }


  ngOnDestroy() {
    if (this.timerid) { clearInterval(this.timerid); }

    if (this.datatimer) { clearInterval(this.datatimer) }

  }





  


}
