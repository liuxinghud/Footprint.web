import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { TestData } from '../models/test-data';
@Injectable({
  providedIn: 'root'
})
export class EventService {
  private eventmsg = new Subject<TestData>();
  public message: TestData[] = [];
  constructor() { }

  publish(msg: TestData) {
    this.eventmsg.next(msg);
    if (this.message.length > 99) {
      this.cleareMsg();
    }
    this.message.push(msg);

  }
  subevent(): Observable<TestData> {
    return this.eventmsg.asObservable();
  }
  cleareMsg() {
    this.message = [];
  }


}
