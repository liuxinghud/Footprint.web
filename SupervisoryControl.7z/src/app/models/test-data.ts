export class TestData {
    time: Date;
    metric: string;
    value: number;
    constructor(time: Date, metric: string, value: number) {
        this.time = time;
        this.metric = metric;
        this.value = value;
    }

}

