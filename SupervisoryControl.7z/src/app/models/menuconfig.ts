export class Menuconfig {
   public static appitems = [
        {
            label: '电站',
            // faIcon: 'fab fa-500px',
            icon:'power',
            items: [
                {
                    label: '电站-A',
                    link: '/pageone',
                    faIcon: 'fab fa-accessible-icon'
                },
                {
                    label: '电站-B',
                    link: '/pagetwo',
                    faIcon: 'fab fa-accessible-icon',
                    // items: [
                    //     {
                    //         label: '电站-B-1',
                    //         link: '/pagetwo',
                    //         faIcon: 'fas fa-allergies'
                    //     },
                    //     {
                    //         label: '电站-B-2',
                    //         link: '/item-1-2-1',
                    //         faIcon: 'fas fa-ambulance',
                            
                    //     }
                    // ]
                }
            ]
        },
        {
            label: '工单',
            icon: 'alarm',
            items: [
                {
                    label: '未分配',
                    link: '/item-2-1',
                    faIcon: 'fab fa-accessible-icon',
                    // icon: 'favorite'
                },
                {
                    label: '已分配',
                    link: '/item-2-2',
                    faIcon: 'fab fa-accessible-icon',
                    // icon: 'favorite_border'
                }
            ]
        },
        {
            label: '个人配置',
            link: '/item-3',
            icon: 'offline_pin'
        },
        {
            label: 'Item 4',
            link: '/item-4',
            icon: 'star_rate',
            hidden: true
        }
    ];

   static config = {
        paddingAtStart: true,
        classname: 'my-custom-class',
        listBackgroundColor: '#000',
        fontColor: 'white',
        backgroundColor: '#000',
        selectedListFontColor: 'red',
      };

}
