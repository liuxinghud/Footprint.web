import { Component, OnInit } from '@angular/core';
import { Menuconfig } from './models/menuconfig';
import { Router } from '@angular/router';
import { EventService } from './providers/event.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  items = Menuconfig.appitems;
  cfg = Menuconfig.config;
  eventnum: number = 0;
  constructor(private route: Router, private event: EventService) {

  }

  ngOnInit() {
    this.event.subevent().subscribe(x => {
      this.eventnum = this.event.message.length;
    })
  }
  selectedItem(event) {
    this.route.navigate([event.link])
    // faIcon:"fab fa-accessible-icon"
    // id:"82baiHhKNKToBo6caiUr"
    // label:"电站-A"
    // link:"/pageone"
  }
}
