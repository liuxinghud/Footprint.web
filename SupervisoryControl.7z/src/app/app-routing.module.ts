import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { OneComponent } from './pages/one/one.component';
import { TwoComponent } from './pages/two/two.component';
import { ThreeComponent } from './pages/three/three.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
const appRoutes: Routes = [
    { path: 'pageone', component:OneComponent},
    { path: 'pagetwo', component:TwoComponent},
    { path: 'pagethree', component:ThreeComponent},
    { path: '', redirectTo: 'pageone', pathMatch: 'full' },
    { path: '**', component: NotFoundComponent }
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, {
            useHash: false,
            enableTracing: false, // <-- debugging purposes only
            preloadingStrategy: PreloadAllModules
        })
    ],
    exports: [
        RouterModule
    ],
    providers: [
        // AuthService, AuthGuard
    ]
})


export class AppRoutingModule {

}
