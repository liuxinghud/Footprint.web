import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-headerbar',
  templateUrl: './headerbar.component.html',
  styleUrls: ['./headerbar.component.css']
})
export class HeaderbarComponent implements OnInit {

  @Input()
  bgcolor: string = "#666666";//背景颜色
  @Input()
  title: string = "";//背景颜色
  @Input()
  eventnum: number =0;//背景颜色


  constructor() { }
  ngOnInit() {
  }

}
