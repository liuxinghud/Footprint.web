import { Component, OnInit, Input, OnDestroy, AfterViewInit } from '@angular/core';
import { EventService } from '../../providers/event.service';
import { TestData } from '../../models/test-data';
@Component({
  selector: 'app-event-message',
  templateUrl: './event-message.component.html',
  styleUrls: ['./event-message.component.css']
})
export class EventMessageComponent implements OnInit, OnDestroy, AfterViewInit {
  messages: TestData[] = [];
  timerid: any;
  @Input()
  fontcolor: string = "#000";
  constructor(private msg: EventService) { }
  ngOnInit() {
    this.msg.subevent().subscribe(x => {
      if (this.messages.length > 4) {
        this.messages.splice(0, this.messages.length - 4);
      }
      this.messages.push(x);
    });
  }

  ngAfterViewInit() {
    this.timerid = setInterval(() => {
      if (this.messages.length > 0) {
        this.messages.splice(0, 1);
      }
    }, 5000)
  }


  ngOnDestroy() {
    if (this.timerid) {
      clearInterval(this.timerid);
    }
  }
}
